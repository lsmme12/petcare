<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>메인 페이지</title>
</head>
<body>

<h2 style="text-align:center;">🐾 PET CARE 게시판 메인</h2>

<p style="text-align:center;">
    <!-- 게시글 목록으로 이동 (Controller 경유) -->
    <a href="${pageContext.request.contextPath}/post/list.do">📋 게시글 목록 보기</a>
</p>

</body>
</html>
