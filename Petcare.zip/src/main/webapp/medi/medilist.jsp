<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List,com.pet.dao.MediRecordDAO,com.pet.dto.MediRecordDTO,com.pet.dao.PetDAO,com.pet.dto.PetDTO" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%--
  medilist.jsp
  - 목적: 특정 반려동물(petId)의 투약기록을 목록으로 보여줍니다.
--%>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>투약기록 목록</title>
  <style>
    body { font-family: system-ui, sans-serif; padding: 24px; }
    .medi-list { list-style: none; padding: 0; margin: 0; max-width: 720px; }
    .medi-list li { border: 1px solid #e5e7eb; border-radius: 8px; padding: 10px 12px; margin-bottom: 8px; }
    .medi-item { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; align-items: center; }
    .medi-item .label { color:#6b7280; margin-right:6px; }
    .actions { margin-top: 6px; }
    .actions a, .actions button { margin-right:8px; }
  </style>
</head>
<body>
  <h1>투약기록 목록</h1>
<%
    String petIdStr = request.getParameter("petId");
    int petId = 1;
    try { petId = Integer.parseInt(petIdStr); } catch(Exception ignore) {}
    MediRecordDAO dao = new MediRecordDAO();
    List<MediRecordDTO> list = dao.list(petId);
    PetDAO petDao = new PetDAO();
    PetDTO pet = petDao.getPetById(petId);
    String petName = (pet != null && pet.getPetName() != null) ? pet.getPetName() : "알수없음";
%>
  <p>강아지 이름: <strong><%= petName %></strong> | <a href="mediadd.jsp?petId=<%=petId%>">추가</a> | <a href="../index.jsp">메인</a></p>

  <ul class="medi-list">
  <%
    if (list == null || list.isEmpty()) {
  %>
    <li>등록된 투약기록이 없습니다.</li>
  <%
    } else {
      for (MediRecordDTO m : list) {
  %>
    <li>
      <div class="medi-item">
        <div><span class="label">Record ID:</span><%= m.getRecordId() %></div>
        <div><span class="label">약품명:</span><%= m.getMedicine() %></div>
        <div><span class="label">투약시각:</span><%= m.getDosageTimeFormatted() %></div>
        <div class="actions">
          <form action="medidelete.jsp" method="post" style="display:inline" onsubmit="return confirm('삭제하시겠습니까?');">
            <input type="hidden" name="recordId" value="<%=m.getRecordId()%>">
            <input type="hidden" name="petId" value="<%=petId%>">
            <button type="submit">삭제</button>
          </form>
        </div>
      </div>
    </li>
  <%
      }
    }
  %>
  </ul>
</body>
</html>
